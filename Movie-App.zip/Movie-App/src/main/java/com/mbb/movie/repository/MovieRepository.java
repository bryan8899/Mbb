package com.mbb.movie.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.mbb.movie.entity.Movie;

/**
 * @author bryan
 * @date 19/02/2021
 * @description This is a repository class to find the movie by title
 */
public interface MovieRepository extends JpaRepository<Movie,Integer> {
    Movie findByTitle(String title);
}

