package com.mbb.movie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author bryan
 * @date 19/02/2021
 * @description This is a  class to bring up the application, it will start up Tomcat consuming port 12000, after Tomcat is started up, 
 *              can bring up PostMan to start testing based on URL, method and JSON method commented in MovieController class
 */
@SpringBootApplication
public class MbbMovieApplication {

	public static void main(String[] args) {
		SpringApplication.run(MbbMovieApplication.class, args);
	}

}
