package com.mbb.client;

import java.util.Arrays;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class RestClient{

	public static final String GET_ALL_MOVIES_API="http://localhost:12000/movies";
	

	static RestTemplate restTemplate=new RestTemplate();
	public static void main (String[]args) {
		callGetALLUsersAPI();
	}
	
	private static void callGetALLUsersAPI() {
		HttpHeaders headers =new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		
		HttpEntity<String> entity= new HttpEntity<>("parameters",headers);
		ResponseEntity<String> result =restTemplate.exchange(GET_ALL_MOVIES_API, HttpMethod.GET, entity, String.class);
		System.out.println(result);
	}
}