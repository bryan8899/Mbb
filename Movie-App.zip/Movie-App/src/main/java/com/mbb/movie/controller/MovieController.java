package com.mbb.movie.controller;

import com.mbb.movie.entity.Movie;
import  com.mbb.movie.service.MovieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author bryan
 * @date 19/02/2021
 * @description This is a controller class to send POST/GET/PUT/DELETE request on POSTMAN at the following url for example: http://localhost:12000/addProduct, 
 *              addProduct uri can be replaced with respective other uri 
 */

@RestController
public class MovieController {

    @Autowired
    private MovieService service;

    /*Please use this url with POST method to test http://localhost:12000/addMovie example JSON: 	{
	"title":"Avengers: Infinity War",
	"category":"science fiction",
	"rating":5
	}
	*/
    @PostMapping("/addMovie")
    public Movie addMovie(@RequestBody Movie movie) {
        return service.saveMovie(movie);
    }
    
    /*Please use this url with POST method to test http://localhost:12000/addMovies example JSON: 	{
   	[
	{
	"title":"Avengers: EndGame",
	"category":"science fiction",
	"rating":5
	},
	{
	"title":"The Avengers",
	"category":"science fiction",
	"rating":5	
	}
	]
   	}
   	*/
    @PostMapping("/addMovies")
    public List<Movie> addMovies(@RequestBody List<Movie> movies) {
        return service.saveMovies(movies);
    }

    /*Please use this url with GET method to test http://localhost:12000/movies to get the list of all movies from the database
   	*/
    @GetMapping("/movies")
    public List<Movie> findAllMovies() {
        return service.getMovies();
    }
    
    /*Please use this url with GET method to test http://localhost:12000/movieById/{ID}, for example http://localhost:12000/movieById/1, 1 is the first row of movie_tbl table
   	*/
    @GetMapping("/movieById/{id}")
    public Movie findMovieById(@PathVariable int id) {
        return service.getMovieById(id);
    }
    
    /*Please use this url with GET method to test http://localhost:12000/movie/Avengers: Infinity Wars, 
   	*/
    @GetMapping("/movie/{title}")
    public Movie findMovieByName(@PathVariable String title) {
        return service.getMovieByTitle(title);
    }
    
    /*Please use this url with PUT method to test http://localhost:12000/update, example JSON to be used as follows:
    {
	"id":1,
	"title":"The Avengers",
	"category":"science fiction",
	"rating":4.3
	}
   	*/
    @PutMapping("/update")
    public Movie updateMovie(@RequestBody Movie movie) {
        return service.updateMovie(movie);
    }

    /*Please use this url with DELETE method to test http://localhost:12000/delete/{ID}, where ID is  value of database table movie_tbl column value defined for ID to remove particular movie from the database
   	*/
    @DeleteMapping("/delete/{id}")
    public String deleteMovie(@PathVariable int id) {
        return service.deleteMovie(id);
    }
}
