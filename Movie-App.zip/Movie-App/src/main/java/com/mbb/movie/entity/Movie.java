package com.mbb.movie.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author bryan
 * @date 19/2/2021
 * @description This is a entity class for movie that will contain the corresponding table and their columns in MYSQL database under moviedb schema 
 *              and movie_tbl table GeneratedValue is set of strategy of IDENTITY for auto increment of the column id in the schema moviedb
 *              
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "MOVIE_TBL")
public class Movie {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
	private String title;
    private String category;
    private double rating;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public double getRating() {
		return rating;
	}
	public void setRating(double rating) {
		this.rating = rating;
	}


}
