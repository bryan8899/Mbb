package com.mbb.movie.service;


import com.mbb.movie.entity.Movie;
import com.mbb.movie.repository.MovieRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author bryan
 * @date 19/02/2021
 * @description This is a  class to implement common functionalities like save, find, delete extended from CrudRepository and method findByTitle defined in movieRepository
 */
@Service
public class MovieService {
    @Autowired
    private MovieRepository repository;

    public Movie saveMovie(Movie movie) {
        return repository.save(movie);
    }

    public List<Movie> saveMovies(List<Movie> movies) {
        return repository.saveAll(movies);
    }

    public List<Movie> getMovies() {
        return repository.findAll();
    }

    public Movie getMovieById(int id) {
        return repository.findById(id).orElse(null);
    }

    public Movie getMovieByTitle(String title) {
        return repository.findByTitle(title);
    }

    public String deleteMovie(int id) {
        repository.deleteById(id);
        return "movie removed !! " + id;
    }

    public Movie updateMovie(Movie movie) {
    	Movie existingMovie = repository.findById(movie.getId()).orElse(null);
    	existingMovie.setTitle(movie.getTitle());
    	existingMovie.setCategory(movie.getCategory());
    	existingMovie.setRating(movie.getRating());
    	return repository.save(existingMovie);
    }


}
